# FuturePath

FuturePath is a college and career planning platform designed for students and parents. Built with React and deployed on AWS Amplify.

## Features
- Student & Parent Dashboards
- Career Assessment Integration
- Mentorship and Financial Planning Tools

## Setup
```bash
npm install
npm start
```
