import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, PutCommand } from "@aws-sdk/lib-dynamodb";

const ddbClient = new DynamoDBClient({});
const ddbDocClient = DynamoDBDocumentClient.from(ddbClient);

export const handler = async (event) => {
    const userId = event.request.userAttributes.sub;
    const email = event.request.userAttributes.email;

    const params = {
        TableName: 'FuturePathUsers-dev',
        Item: {
            userId: userId,
            name: '',
            age: '',
            username: email,
            school: '',
            district: '',
            careerPath: ''
        }
    };

    try {
        await ddbDocClient.send(new PutCommand(params));
        console.log('✅ User added to DynamoDB:', userId);
    } catch (error) {
        console.error('❌ Error writing to DynamoDB:', error);
    }

    return event;
};
